'use client'

import { useState } from 'react'
import {
  Activity,
  ArrowUpRight,
  Bell,
  CalendarDays,
  Check,
  ChevronRight,
  CircleHelp,
  Droplets,
  HeartPulse,
  Home,
  Leaf,
  Menu,
  MessageCircle,
  MoreHorizontal,
  Search,
  ShieldCheck,
  Sparkles,
  SunMedium,
  UserRound,
  X,
} from 'lucide-react'

const navItems = [
  { label: 'Ringkasan', icon: Home },
  { label: 'Perawatan wajah', icon: Sparkles },
  { label: 'Kesehatan', icon: HeartPulse },
  { label: 'Jurnal harian', icon: CalendarDays },
]

const week = [
  { day: 'Sen', date: '21', score: 76 },
  { day: 'Sel', date: '22', score: 84 },
  { day: 'Rab', date: '23', score: 68 },
  { day: 'Kam', date: '24', score: 91 },
  { day: 'Jum', date: '25', score: 88 },
  { day: 'Sab', date: '26', score: 94 },
  { day: 'Min', date: '27', score: 82 },
]

const routine = [
  { title: 'Cleanser lembut', type: 'Pagi · 2 menit', done: true },
  { title: 'Serum niacinamide', type: 'Pagi · 1 menit', done: true },
  { title: 'Moisturizer + SPF 30', type: 'Pagi · 1 menit', done: false },
]

export default function Page() {
  const [activeNav, setActiveNav] = useState('Ringkasan')
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [checked, setChecked] = useState(routine.map((item) => item.done))

  const toggleRoutine = (index: number) => {
    setChecked((items) => items.map((item, itemIndex) => itemIndex === index ? !item : item))
  }

  return (
    <main className="min-h-screen bg-[#f7faff] text-[#13243c]">
      <div className="mx-auto flex min-h-screen max-w-[1500px]">
        <aside className={`${isMenuOpen ? 'translate-x-0' : '-translate-x-full'} fixed inset-y-0 left-0 z-40 flex w-[264px] flex-col border-r border-[#dce8f1] bg-white px-5 py-6 transition-transform lg:relative lg:translate-x-0`}>
          <div className="flex items-center justify-between px-3">
            <div className="flex items-center gap-2.5">
              <span className="flex size-9 items-center justify-center rounded-[12px] bg-[#dff4f2] text-[#1d9b93]"><Leaf size={19} strokeWidth={2.5} /></span>
              <span className="font-display text-[21px] font-semibold tracking-[-0.04em]">nurture<span className="text-[#21a19b]">.</span></span>
            </div>
            <button className="text-[#8291a3] lg:hidden" onClick={() => setIsMenuOpen(false)} aria-label="Tutup menu"><X size={20} /></button>
          </div>
          <p className="mb-3 mt-12 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#98a7b7]">Menu utama</p>
          <nav className="space-y-1">
            {navItems.map(({ label, icon: Icon }) => (
              <button key={label} onClick={() => { setActiveNav(label); setIsMenuOpen(false) }} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-medium transition ${activeNav === label ? 'bg-[#eaf8f7] text-[#167f7b]' : 'text-[#708095] hover:bg-[#f4f8fb]'}`}>
                <Icon size={18} strokeWidth={activeNav === label ? 2.5 : 2} />{label}
              </button>
            ))}
          </nav>
          <p className="mb-3 mt-10 px-3 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#98a7b7]">Lainnya</p>
          <nav className="space-y-1">
            <button className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-medium text-[#708095] hover:bg-[#f4f8fb]"><MessageCircle size={18} />Tanya Nuri <span className="ml-auto rounded-full bg-[#e4f2ff] px-1.5 py-0.5 text-[10px] text-[#4288c5]">2</span></button>
            <button className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-medium text-[#708095] hover:bg-[#f4f8fb]"><CircleHelp size={18} />Bantuan</button>
          </nav>
          <div className="mt-auto rounded-2xl bg-[#f2fafb] p-4">
            <div className="mb-3 flex size-8 items-center justify-center rounded-full bg-white text-[#28a19b]"><ShieldCheck size={17} /></div>
            <p className="text-[12px] font-semibold text-[#315467]">Data kamu aman</p>
            <p className="mt-1 text-[11px] leading-relaxed text-[#7a98a5]">Privasi dan keamanan selalu jadi prioritas kami.</p>
          </div>
          <button className="mt-5 flex items-center gap-3 px-3 text-left"><span className="flex size-9 items-center justify-center rounded-full bg-[#dce9f2] text-[#607d91]"><UserRound size={17} /></span><span className="flex-1"><span className="block text-[12px] font-semibold">Alya Putri</span><span className="text-[11px] text-[#92a0ae]">Profil saya</span></span><MoreHorizontal size={16} className="text-[#99a7b5]" /></button>
        </aside>

        <section className="min-w-0 flex-1">
          <header className="flex h-[78px] items-center justify-between border-b border-[#e3edf4] bg-white/80 px-5 sm:px-8 lg:px-10">
            <button className="text-[#6d8296] lg:hidden" onClick={() => setIsMenuOpen(true)} aria-label="Buka menu"><Menu size={21} /></button>
            <div className="relative hidden max-w-[340px] flex-1 md:block"><Search size={17} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9babb9]" /><input className="h-10 w-full rounded-xl border border-[#e4edf3] bg-[#f8fbfd] pl-10 pr-4 text-[12px] outline-none placeholder:text-[#9babb9] focus:border-[#9cdad5]" placeholder="Cari di nurture..." aria-label="Cari" /></div>
            <div className="ml-auto flex items-center gap-4"><button className="relative text-[#708397]" aria-label="Notifikasi"><Bell size={19} /><span className="absolute -right-1 -top-1 size-1.5 rounded-full bg-[#ef8f74]" /></button><div className="h-6 w-px bg-[#e4edf3]" /><button className="flex items-center gap-2 text-left"><span className="flex size-8 items-center justify-center rounded-full bg-[#d9eff0] text-[12px] font-semibold text-[#258e8b]">AP</span><span className="hidden text-[12px] font-medium text-[#425b70] sm:block">Alya Putri</span></button></div>
          </header>

          <div className="space-y-6 px-5 py-7 sm:px-8 lg:px-10 lg:py-9">
            <div className="flex flex-wrap items-end justify-between gap-4"><div><p className="mb-2 text-[12px] font-medium text-[#7990a3]">Sabtu, 26 Oktober 2024</p><h1 className="font-display text-[30px] font-semibold tracking-[-0.045em] text-[#1b3048] sm:text-[34px]">Selamat pagi, Alya</h1><p className="mt-2 text-[13px] text-[#72879a]">Jaga ritmemu hari ini, satu langkah kecil sudah berarti.</p></div><button className="flex items-center gap-2 rounded-xl bg-[#1f9d97] px-4 py-2.5 text-[12px] font-semibold text-white shadow-[0_7px_18px_rgba(31,157,151,0.18)] transition hover:bg-[#188b86]"><Sparkles size={15} />Mulai check-in</button></div>

            <div className="grid gap-4 md:grid-cols-3"><StatCard icon={<HeartPulse size={18} />} label="Kesehatan hari ini" value="82" suffix="/100" note="+6 dari kemarin" tone="teal" /><StatCard icon={<Droplets size={18} />} label="Hidrasi" value="1.4" suffix="L / 2L" note="60% target harian" tone="blue" /><StatCard icon={<SunMedium size={18} />} label="Paparan UV" value="Rendah" suffix="" note="Waktu aman hingga 10.30" tone="coral" /></div>

            <div className="grid gap-5 xl:grid-cols-[1.55fr_1fr]">
              <section className="rounded-2xl border border-[#dfeaf2] bg-white p-5 shadow-[0_12px_35px_rgba(43,84,116,0.04)] sm:p-6"><div className="mb-6 flex items-center justify-between"><div><h2 className="font-display text-[18px] font-semibold tracking-[-0.03em]">Keseimbangan mingguan</h2><p className="mt-1 text-[12px] text-[#8496a6]">Ringkasan dari check-in dan jurnal harianmu</p></div><button className="flex items-center gap-1 text-[11px] font-semibold text-[#258e8b]">Lihat detail <ArrowUpRight size={14} /></button></div><div className="flex h-[190px] items-end justify-between gap-2 px-1 sm:gap-5">{week.map((item, index) => <div key={item.day} className="flex h-full flex-1 flex-col items-center justify-end gap-2"><div className="relative flex h-[155px] w-full items-end justify-center"><div className={`w-full max-w-[28px] rounded-t-[8px] ${index === 5 ? 'bg-[#2aa6a0]' : 'bg-[#d9f0ef]'}`} style={{ height: `${item.score}%` }} />{index === 5 && <span className="absolute -top-7 rounded-md bg-[#19364a] px-2 py-1 text-[10px] font-semibold text-white">94</span>}</div><span className={`text-[11px] ${index === 5 ? 'font-semibold text-[#1e9892]' : 'text-[#94a3b0]'}`}>{item.day}</span><span className="text-[11px] font-medium text-[#647e91]">{item.date}</span></div>)}</div></section>

              <section className="rounded-2xl border border-[#dfeaf2] bg-[#eef9f8] p-5 sm:p-6"><div className="mb-5 flex items-center justify-between"><div><p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-[#5d9896]">Insight untukmu</p><h2 className="mt-2 font-display text-[19px] font-semibold tracking-[-0.03em] text-[#20485a]">Kulitmu butuh jeda</h2></div><span className="flex size-9 items-center justify-center rounded-xl bg-white text-[#2aa39c]"><Leaf size={18} /></span></div><p className="text-[13px] leading-relaxed text-[#557985]">Dari catatanmu minggu ini, kulit terlihat lebih sensitif setelah hari yang panjang. Coba sederhanakan rutinitas malam ini.</p><div className="mt-5 flex items-center justify-between border-t border-[#d5eeeb] pt-4"><span className="text-[11px] font-medium text-[#6b9295]">Berdasarkan 4 catatan</span><button className="flex items-center gap-1 text-[11px] font-semibold text-[#208c87]">Buka jurnal <ChevronRight size={14} /></button></div></section>
            </div>

            <div className="grid gap-5 xl:grid-cols-[1fr_1.55fr]"><section className="rounded-2xl border border-[#dfeaf2] bg-white p-5 shadow-[0_12px_35px_rgba(43,84,116,0.04)] sm:p-6"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-display text-[18px] font-semibold tracking-[-0.03em]">Rutinitas pagi</h2><p className="mt-1 text-[12px] text-[#8496a6]">3 langkah · sekitar 4 menit</p></div><button className="text-[#91a1af]" aria-label="Opsi rutinitas"><MoreHorizontal size={18} /></button></div><div className="space-y-3">{routine.map((item, index) => <button key={item.title} onClick={() => toggleRoutine(index)} className="flex w-full items-center gap-3 text-left"><span className={`flex size-7 shrink-0 items-center justify-center rounded-lg border ${checked[index] ? 'border-[#2ca59e] bg-[#2ca59e] text-white' : 'border-[#d4e1e9] bg-white text-transparent'}`}><Check size={15} strokeWidth={3} /></span><span className="flex-1"><span className={`block text-[12px] font-medium ${checked[index] ? 'text-[#8296a5] line-through' : 'text-[#3c566a]'}`}>{item.title}</span><span className="mt-0.5 block text-[10px] text-[#9aabb8]">{item.type}</span></span></button>)}</div><button className="mt-6 flex w-full items-center justify-center gap-1.5 rounded-xl border border-[#d9e8ef] py-2.5 text-[11px] font-semibold text-[#4b7488] hover:bg-[#f7fbfc]">Lihat rutinitas lengkap <ChevronRight size={14} /></button></section>
              <section className="rounded-2xl border border-[#dfeaf2] bg-white p-5 shadow-[0_12px_35px_rgba(43,84,116,0.04)] sm:p-6"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-display text-[18px] font-semibold tracking-[-0.03em]">Aktivitas terakhir</h2><p className="mt-1 text-[12px] text-[#8496a6]">Catatan kesehatan dan perawatanmu</p></div><button className="text-[11px] font-semibold text-[#258e8b]">Lihat semua</button></div><div className="grid gap-3 sm:grid-cols-3"><ActivityItem icon={<Droplets size={17} />} title="Minum air" time="Hari ini, 08.12" value="+250 ml" tone="blue" /><ActivityItem icon={<Sparkles size={17} />} title="Rutinitas wajah" time="Hari ini, 07.40" value="Selesai" tone="teal" /><ActivityItem icon={<Activity size={17} />} title="Mood check-in" time="Kemarin, 21.05" value="Tenang" tone="lavender" /></div><div className="mt-5 flex items-center gap-3 rounded-xl bg-[#f7fafc] px-4 py-3"><span className="flex size-8 items-center justify-center rounded-full bg-white text-[#e0a264]"><SunMedium size={16} /></span><p className="text-[11px] leading-relaxed text-[#71899a]">Jangan lupa re-apply sunscreen sebelum keluar siang nanti.</p></div></section></div>
          </div>
        </section>
      </div>
    </main>
  )
}

function StatCard({ icon, label, value, suffix, note, tone }: { icon: React.ReactNode; label: string; value: string; suffix: string; note: string; tone: 'teal' | 'blue' | 'coral' }) {
  const colors = { teal: 'bg-[#e5f7f4] text-[#299d96]', blue: 'bg-[#e6f2ff] text-[#4b91c6]', coral: 'bg-[#fff0e9] text-[#e28b65]' }
  return <div className="rounded-2xl border border-[#dfeaf2] bg-white p-5 shadow-[0_12px_35px_rgba(43,84,116,0.04)]"><div className="flex items-center gap-3"><span className={`flex size-9 items-center justify-center rounded-xl ${colors[tone]}`}>{icon}</span><span className="text-[12px] font-medium text-[#7d91a2]">{label}</span></div><div className="mt-5 flex items-baseline gap-1"><span className="font-display text-[27px] font-semibold tracking-[-0.04em] text-[#1c3449]">{value}</span><span className="text-[12px] text-[#93a2af]">{suffix}</span></div><p className="mt-1 text-[11px] text-[#86a0ae]">{note}</p></div>
}

function ActivityItem({ icon, title, time, value, tone }: { icon: React.ReactNode; title: string; time: string; value: string; tone: 'blue' | 'teal' | 'lavender' }) {
  const colors = { blue: 'bg-[#eaf4ff] text-[#4a8fc8]', teal: 'bg-[#e8f8f5] text-[#2a9e95]', lavender: 'bg-[#f1edff] text-[#896bc2]' }
  return <div className="rounded-xl border border-[#e5eef3] p-4"><span className={`flex size-8 items-center justify-center rounded-lg ${colors[tone]}`}>{icon}</span><p className="mt-3 text-[12px] font-semibold text-[#3d576a]">{title}</p><p className="mt-1 text-[10px] text-[#9aaab6]">{time}</p><p className="mt-3 text-[11px] font-semibold text-[#5b7a8d]">{value}</p></div>
}
